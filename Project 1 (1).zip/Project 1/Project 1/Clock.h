
#define CLOCK_H

class Clock {
private:
    int hours;
    int minutes;
    int seconds;
    bool is24HourFormat;

public:
    Clock(bool _is24HourFormat = false);
    void setTime(int _hours, int _minutes, int _seconds);
    void toggleFormat();
    void displayTime();
};


