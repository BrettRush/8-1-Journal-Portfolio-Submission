#include <iostream>
#include "Clock.h"

Clock::Clock(bool _is24HourFormat) {
    hours = 0;
    minutes = 0;
    seconds = 0;
    is24HourFormat = _is24HourFormat;
}

void Clock::setTime(int _hours, int _minutes, int _seconds) {
    hours = _hours;
    minutes = _minutes;
    seconds = _seconds;
}

void Clock::toggleFormat() {
    is24HourFormat = !is24HourFormat;
}

void Clock::displayTime() {
    if (is24HourFormat) {
        std::cout << hours << ":" << minutes << ":" << seconds << std::endl;
    }
    else {
        std::cout << (hours % 12 == 0 ? 12 : hours % 12) << ":" << minutes << ":" << seconds
            << (hours < 12 ? " AM" : " PM") << std::endl;
    }
}