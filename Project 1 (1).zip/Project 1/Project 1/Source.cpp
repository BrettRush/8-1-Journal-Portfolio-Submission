#include <iostream>
#include "Clock.h"

int main() {
    Clock clock12(false); // 12-hour format
    Clock clock24(true);  // 24-hour format

    int hours, minutes, seconds;
    std::cout << "Enter initial time (hours minutes seconds):";
    std::cin >> hours >> minutes >> seconds;

    clock12.setTime(hours, minutes, seconds);
    clock24.setTime(hours, minutes, seconds);

    std::cout << "\nClock 1: 12-Hour Format: " << std::endl;
    clock12.displayTime();
    std::cout << "\nClock 2: 24-Hour Format: " << std::endl;
    clock24.displayTime();

    return 0;
}